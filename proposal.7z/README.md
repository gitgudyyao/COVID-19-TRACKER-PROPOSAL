Basic tracker
